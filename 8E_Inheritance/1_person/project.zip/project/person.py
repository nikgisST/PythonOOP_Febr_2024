class Person:

    def __init__(self, nam: str, ag:int):
        self.name = nam
        self.age = ag
